#!/usr/bin/env python3
"""Download the focus and/or full hero images for self-hosting."""

import argparse
import hashlib
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
SOURCE = "https://wepiii2.github.io/strand-backgrounds"
NAME = re.compile(r"(?:focus|full)/[0-9a-f-]{36}\.jpg\Z")
MAX_BYTES = 10 * 1024 * 1024


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fetch(name: str, expected_sha256: str) -> str:
    if not NAME.fullmatch(name):
        raise ValueError("Unexpected image path in catalog")
    destination = ROOT / "images" / name
    if destination.is_file() and digest(destination) == expected_sha256:
        return "existing"
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = Request(SOURCE + "/" + name + "?v=" + expected_sha256[:16],
                      headers={"User-Agent": "StrandBackgroundPack/4.0"})
    with urlopen(request, timeout=45) as response:
        if response.headers.get_content_type() != "image/jpeg":
            raise ValueError(f"Unexpected content type for {name}")
        data = response.read(MAX_BYTES + 1)
    if (len(data) > MAX_BYTES or not data.startswith(b"\xff\xd8\xff")
            or not data.endswith(b"\xff\xd9")
            or hashlib.sha256(data).hexdigest() != expected_sha256):
        raise ValueError(f"Invalid JPEG for {name}")
    temporary = destination.with_suffix(".part")
    temporary.write_bytes(data)
    temporary.replace(destination)
    return "downloaded"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=("focus", "full", "both"), required=True,
                        help="Download only the hero layout you use, or both")
    args = parser.parse_args()
    fields = ["focusFile", "fullFile"] if args.variant == "both" else [args.variant + "File"]
    rows = json.loads((ROOT / "catalog.json").read_text())
    names = [(row[field], row[field.removesuffix("File") + "SHA256"])
             for row in rows for field in fields]
    counts = {"existing": 0, "downloaded": 0}
    with ThreadPoolExecutor(max_workers=8) as pool:
        for future in as_completed([pool.submit(fetch, name, expected)
                                    for name, expected in names]):
            counts[future.result()] += 1
    print(f"Ready: {len(names)} images ({counts['downloaded']} downloaded, {counts['existing']} already present).")


if __name__ == "__main__":
    main()

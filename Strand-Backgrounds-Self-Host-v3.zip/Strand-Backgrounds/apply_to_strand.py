#!/usr/bin/env python3
"""Add self-hosted folder backgrounds to an existing Strand setup export."""

import argparse
import json
from pathlib import Path
from urllib.parse import urlsplit


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Your current .strand export")
    parser.add_argument("output", type=Path, help="New .strand file to create")
    parser.add_argument("--base-url", required=True, help="HTTPS origin hosting images/, e.g. https://art.example.com")
    parser.add_argument("--variant", choices=("focus", "full"), required=True,
                        help="Match your Strand hero layout")
    args = parser.parse_args()
    origin = args.base_url.rstrip("/")
    parsed = urlsplit(origin)
    if parsed.scheme != "https" or not parsed.netloc or parsed.path:
        parser.error("--base-url must be an HTTPS origin without a path")
    if args.input.resolve() == args.output.resolve() or args.output.exists():
        parser.error("output must be a new file separate from input")

    catalog = json.loads((ROOT / "catalog.json").read_text())
    field = "focusFile" if args.variant == "focus" else "fullFile"
    mapping = {(row["group"], row["title"]): row[field] for row in catalog}
    setup = json.loads(args.input.read_text())
    matched = 0
    for shelf in setup["shelves"]:
        group = shelf.get("source", {}).get("group")
        if group is None:
            continue
        group_name = group["_0"].get("title") or shelf["title"]
        for folder in group["_0"]["contentSources"]:
            local_file = mapping.get((group_name, folder["title"]))
            if local_file is None:
                continue
            folder["backgroundImageURL"] = origin + "/" + local_file
            matched += 1
    if matched == 0:
        raise ValueError("No matching folders found; no output written")
    args.output.write_text(json.dumps(setup, indent=2, ensure_ascii=False) + "\n")
    print(f"Added {matched} background URLs. Original export was not changed.")


if __name__ == "__main__":
    main()

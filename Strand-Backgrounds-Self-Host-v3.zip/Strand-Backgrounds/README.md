# Strand shelf backgrounds, focus and full hero

This pack maps 312 individual Strand folders across Streaming Services, Networks,
Studios, Kids and Family, Movie Collections, Genres, and Moods & Vibes. Each
folder has two JPEG backgrounds:

- **Focus-driven hero:** 2400 × 1000, with the identifier centered in the visible band.
- **Full-screen hero:** 1920 × 1080, framed for the full screen.

Choose the variant that matches the hero layout you use in Strand. You can
download just one variant, or both:

```sh
python3 download_images.py --variant focus
# or: python3 download_images.py --variant full
# or: python3 download_images.py --variant both
```

The script downloads the finished artwork to `images/focus/` and/or
`images/full/`. Keep those directories when you copy the files to your own
static web server. Make the files reachable over HTTPS from your Strand
devices. You can host them on the same VM as Trellis with a separate static
service and your existing HTTPS reverse proxy or tunnel; no Trellis addon or
catalog changes are required.

`catalog.json` identifies each folder, both filenames, and the original art
and logo sources where applicable. You can enter a URL manually in Strand's
**Background Image URL** field, for example:

```
https://art.example.com/focus/<id>.jpg
```

To fill matching folders in one pass, export your **current** Strand setup
first. Keep that export as your backup. Then run one of:

```sh
python3 apply_to_strand.py "My Setup.strand" "My Setup With Focus Backgrounds.strand" --base-url https://art.example.com --variant focus
python3 apply_to_strand.py "My Setup.strand" "My Setup With Full Backgrounds.strand" --base-url https://art.example.com --variant full
```

Import the newly created `.strand` file into Strand. The helper changes only
`backgroundImageURL` on folders with matching group and title; it does not
create shelves or alter sources. On Apple TV, enable the row's **Use Image as
Background** option. Keep your `.strand` files private because they may
contain addon URLs and credentials.

The ZIP contains no personal Strand setup, private addon URLs, or credentials.
It downloads the finished images from the public Strand art host so the pack
remains small. The underlying art and logos belong to their respective owners;
review source credits in `catalog.json` and relevant rights before republishing.
For TMDB images, see [TMDB attribution guidance](https://developer.themoviedb.org/docs/faq).
This is an unofficial community pack, unaffiliated with Strand, Trellis, or
the brands shown.
